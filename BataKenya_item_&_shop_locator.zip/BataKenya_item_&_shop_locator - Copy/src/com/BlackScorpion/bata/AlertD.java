package com.BlackScorpion.bata;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;

public class AlertD extends Activity {

	String myMessage;

	@Override
	protected void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);

		Bundle extras = getIntent().getExtras();
		myMessage = extras.getString("myKey");

		SharedPreferences prefs = getSharedPreferences("SmsPrefs",
				Context.MODE_PRIVATE);
		SharedPreferences.Editor editor = prefs.edit();
		editor.putString("Message", myMessage);
		editor.commit();

		Intent newintent = new Intent(AlertD.this, ShowMessage.class);

		startActivity(newintent);

	}

}

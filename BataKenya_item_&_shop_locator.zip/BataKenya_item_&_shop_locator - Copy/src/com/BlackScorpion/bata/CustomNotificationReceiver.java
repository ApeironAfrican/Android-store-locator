package com.BlackScorpion.bata;

import org.json.JSONException;
import org.json.JSONObject;

import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.support.v4.app.NotificationCompat;

import com.parse.ParsePushBroadcastReceiver;

public class CustomNotificationReceiver extends ParsePushBroadcastReceiver {

	NotificationCompat.Builder mBuilder;
	Intent resultIntent;
	int mNotificationId = 001;
	Uri notifySound;
	String text;

	String alert; // This is the message string that send from push console

	@Override
	public void onReceive(Context context, Intent intent) {

		// Get JSON data and put them into variables
		try {

			JSONObject json = new JSONObject(intent.getExtras().getString(
					"com.parse.Data"));

			alert = json.getString("alert").toString();
			text = json.getString("text").toString();

		} catch (JSONException e) {
			e.printStackTrace();
		}

		/*
		 * You can specify sound notifySound = RingtoneManager
		 * .getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
		 */

		mBuilder = new NotificationCompat.Builder(context);
		mBuilder.setSmallIcon(R.drawable.index);
		// You can change your icon
		mBuilder.setContentText(text);
		mBuilder.setContentTitle("Bata");
		/* mBuilder.setSound(notifySound); */
		mBuilder.setAutoCancel(true);

		// this is the activity that we will send the user, change this to
		// anything you want
		resultIntent = new Intent(context, Notifier.class);
		resultIntent.putExtra("newUrl", alert);
		resultIntent.putExtra("textToShow", text);

		PendingIntent resultPendingIntent = PendingIntent.getActivity(context,
				0, resultIntent, PendingIntent.FLAG_UPDATE_CURRENT);

		mBuilder.setContentIntent(resultPendingIntent);

		NotificationManager notificationManager = (NotificationManager) context
				.getSystemService(Context.NOTIFICATION_SERVICE);

		notificationManager.notify(mNotificationId, mBuilder.build());

	}

}

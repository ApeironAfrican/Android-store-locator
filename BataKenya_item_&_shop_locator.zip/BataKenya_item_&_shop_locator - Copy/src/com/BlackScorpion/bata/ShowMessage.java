package com.BlackScorpion.bata;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.webkit.WebSettings.LayoutAlgorithm;
import android.webkit.WebSettings.ZoomDensity;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.TextView;

public class ShowMessage extends Activity {

	WebView myWeb;
	TextView bata, myshops, txtmessage;
	Button find;
	Typeface font;
	String ImageUrl, smsMessage;

	// ProgressBar Bar;

	@SuppressWarnings("deprecation")
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.messagereceiver);

		font = Typeface.createFromAsset(this.getAssets(), "G-Unit.TTF");

		SharedPreferences ImageLoaderPrefs = getSharedPreferences("ImagePrefs",
				Context.MODE_PRIVATE);
		ImageUrl = ImageLoaderPrefs.getString("imageUrl", null);

		SharedPreferences MessagePrefs = getSharedPreferences("SmsPrefs",
				Context.MODE_PRIVATE);
		smsMessage = MessagePrefs.getString("Message", null);

		myWeb = (WebView) findViewById(R.id.myShoeWeb);
		myWeb.getSettings().setLoadWithOverviewMode(true);
		myWeb.getSettings().setUseWideViewPort(true);
		myWeb.setInitialScale(30);
		myWeb.setBackgroundColor(Color.TRANSPARENT);
		myWeb.getSettings().setDefaultZoom(ZoomDensity.FAR);
		myWeb.getSettings().setLayoutAlgorithm(LayoutAlgorithm.SINGLE_COLUMN);

		// myWeb.setWebViewClient(new Client());

		String data = "<html><body><img id=\"resizeImage\"src=\"" + ImageUrl
				+ "\"width=\"100%\" alt=\"\" align=\"middle\"/></body></html>";
		myWeb.loadData(data, "text/html;charset=UTF-8", null);

		// Bar = (ProgressBar) findViewById(R.id.myBar);
		bata = (TextView) findViewById(R.id.textView1);
		myshops = (TextView) findViewById(R.id.till);
		txtmessage = (TextView) findViewById(R.id.messageText);
		find = (Button) findViewById(R.id.SmsButton);

		bata.setTypeface(font);
		txtmessage.setText(smsMessage);

		find.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				Intent intent = new Intent(ShowMessage.this, ShopFinder.class);
				startActivity(intent);
				overridePendingTransition(R.anim.slide_in_left,
						R.anim.slide_out_left);
			}
		});

	}

	/*
	 * class Client extends WebViewClient {
	 * 
	 * @Override public void onPageFinished(WebView view, String url) { // TODO
	 * Auto-generated method stub view.loadUrl(url);
	 * Bar.setVisibility(View.GONE); super.onPageFinished(view, url); }
	 * 
	 * @JavascriptInterface public void onReceivedError(WebView view, int
	 * errorCode, String description, String failingUrl) {
	 * 
	 * Toast.makeText(ShowMessage.this, "Sorry cant load the image" +
	 * description, Toast.LENGTH_LONG).show(); };
	 * 
	 * }
	 */

}

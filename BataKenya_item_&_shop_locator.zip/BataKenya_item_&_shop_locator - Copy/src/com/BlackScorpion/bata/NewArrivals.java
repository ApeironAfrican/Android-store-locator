package com.BlackScorpion.bata;

import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Build;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

@TargetApi(Build.VERSION_CODES.HONEYCOMB)
@SuppressLint({ "SetJavaScriptEnabled", "JavascriptInterface" })
public class NewArrivals extends Activity {

	ProgressBar progress;
	TextView contentView, leString;

	WebView wv;
	String code;
	String name;

	WebView web;
	String theUrlToLoad;
	String ArrivalUrl;
	String fromNotifier;

	@SuppressLint("WorldReadableFiles")
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.parsexml);

		contentView = (TextView) findViewById(R.id.myShoeCode);
		leString = (TextView) findViewById(R.id.myShoeName);
		progress = (ProgressBar) findViewById(R.id.myProgressBar);
		web = (WebView) findViewById(R.id.myWeb);

		// Data from the mainActivity class
		Bundle bundle = getIntent().getExtras();
		ArrivalUrl = bundle.getString("fromNewArrivals");

		// Data from the notifier class
		Bundle newBundle = getIntent().getExtras();
		fromNotifier = newBundle.getString("myString");

		webSettings();

	}

	@JavascriptInterface
	private void webSettings() {
		// TODO Auto-generated method stub

		web.getSettings().setLoadWithOverviewMode(true);
		web.getSettings().setUseWideViewPort(true);
		web.getSettings().setJavaScriptEnabled(true);

		@SuppressLint("JavascriptInterface")
		@SuppressWarnings("unused")
		class MyJavascriptInterface {

			private TextView contentView;

			public MyJavascriptInterface(TextView aContentView) {
				contentView = aContentView;
			}

			public void processContent(String aContent) {
				final String content = aContent;
				contentView.post(new Runnable() {

					@Override
					public void run() {
						// TODO Auto-generated method stub
						contentView.setText(content);
					}
				});
			}
		}

		web.addJavascriptInterface(new MyJavascriptInterface(contentView),
				"INTERFACE");

		@SuppressWarnings("unused")
		class TheJavascriptInterface {

			private TextView leString;

			public TheJavascriptInterface(TextView aString) {
				leString = aString;

			}

			public void processContent(String bString) {
				final String theString = bString;

				leString.post(new Runnable() {

					@Override
					public void run() {
						// TODO Auto-generated method stub
						leString.setText(theString);
					}
				});

			}
		}

		web.addJavascriptInterface(new TheJavascriptInterface(leString),
				"INTER");
		web.setWebViewClient(new Client());
		// web.setBackgroundResource(android.);

		if (fromNotifier == null) {

			// web.loadUrl(ArrivalUrl);
			String data = "<html><body><img id=\"resizeImage\"src=\""
					+ ArrivalUrl
					+ "\"width=\"100%\" alt=\"\" align=\"middle\"/></body></html>";
			web.loadData(data, "text/html;charset=UTF-8", null);

		} else {

			// web.loadUrl(fromNotifier);
			String data = "<html><body><img id=\"resizeImage\"src=\""
					+ fromNotifier
					+ "\"width=\"100%\" alt=\"\" align=\"middle\"/></body></html>";
			web.loadData(data, "text/html;charset=UTF-8", null);
		}

	}

	class Client extends WebViewClient {

		@JavascriptInterface
		@Override
		public void onPageFinished(WebView view, String url) {
			// TODO Auto-generated method stub
			view.loadUrl("javascript:window.INTERFACE.processContent(document.getElementsByName('productSKUCode')[0].value);");
			view.loadUrl("javascript:window.INTER.processContent(document.getElementsByName('productName')[0].value);");
			progress.setVisibility(View.GONE);
			super.onPageFinished(view, url);
		}

		@Override
		public void onPageStarted(WebView view, String url, Bitmap favicon) {
			// TODO Auto-generated method stub
			progress.setVisibility(View.VISIBLE);
			super.onPageStarted(view, url, favicon);
		}

		@JavascriptInterface
		public void onReceivedError(WebView view, int errorCode,
				String description, String failingUrl) {

			Toast.makeText(NewArrivals.this,
					"Sorry cant load the page" + description, Toast.LENGTH_LONG)
					.show();
		};

		@JavascriptInterface
		@Override
		public boolean shouldOverrideUrlLoading(WebView view, String url) {
			// TODO Auto-generated method stub

			view.loadUrl(url);
			return true;
		}
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		super.onCreateOptionsMenu(menu);
		MenuInflater blow = getMenuInflater();
		blow.inflate(R.menu.newarrivals, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// TODO Auto-generated method stub
		switch (item.getItemId()) {
		case R.id.fowardAction:
			if (web.canGoForward())
				web.goForward();

			break;
		case R.id.backAction:
			if (web.canGoBack())
				web.goBack();
			break;
		case R.id.reloadAction:
			web.reload();

			break;
		case R.id.send:
			code = contentView.getText().toString();
			name = leString.getText().toString();

			if (code.length() == 7) {

				Bundle basket = new Bundle();
				basket.putString("Code", code);
				basket.putString("Name", name);

				Intent send = new Intent(getApplicationContext(),
						SmsActivity.class);
				send.putExtras(basket);
				startActivity(send);
				overridePendingTransition(R.anim.slide_in_left,
						R.anim.slide_out_left);

			} else {
				Toast.makeText(NewArrivals.this,
						"Please select a specific item", Toast.LENGTH_LONG)
						.show();
			}
			break;
		case R.id.homeAction:
			Intent hm = new Intent("com.BlackScorpion.bata.MAINACTIVITY");
			startActivity(hm);
			overridePendingTransition(R.anim.slide_in_left,
					R.anim.slide_out_left);
			break;

		}
		return false;
	}

	@Override
	protected void onPause() {
		// TODO Auto-generated method stub
		super.onPause();
		finish();
	}

}

package com.BlackScorpion.bata;

import java.util.ArrayList;
import java.util.List;

import android.app.ActionBar;
import android.app.Activity;
import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

public class ShopFinder extends Activity {

	Typeface font;
	private List<shops> myShops = new ArrayList<shops>();

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.listview_activity);

		populateMyList();
		populateMyListView();
		setClickAction();

		font = Typeface.createFromAsset(this.getAssets(), "G-Unit.TTF");
		TextView textView = (TextView) findViewById(R.id.selectShop);
		textView.setText("Shops in Nairobi area...");
		textView.setTypeface(font);

		ActionBar myBar = getActionBar();
		myBar.hide();
	}

	private void setClickAction() {
		// TODO Auto-generated method stub
		ListView list = (ListView) findViewById(R.id.myListView);
		list.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> parent, View myView,
					int position, long id) {
				// TODO Auto-generated method stub
				int shopsCode;
				shops clickedShop = myShops.get(position);

				shopsCode = clickedShop.getCode();

				Bundle basket = new Bundle();
				basket.putInt("mapCode", shopsCode);
				Intent theIntent = new Intent(
						"com.BlackScorpion.bata.MAPSACTIVITY");
				theIntent.putExtras(basket);
				startActivity(theIntent);
				overridePendingTransition(R.anim.slide_in_left,
						R.anim.slide_out_left);

				

			}
		});
	}

	private void populateMyListView() {

		ArrayAdapter<shops> adapter = new MyListAdapter();
		ListView theList = (ListView) findViewById(R.id.myListView);
		theList.setAdapter(adapter);

	}

	private void populateMyList() {
		// TODO Auto-generated method stub
		myShops.add(new shops("Hilton (Nairobi 2)", "Kencom st",
				R.drawable.hilton, null, 1));
		myShops.add(new shops("River Road(1)", "River Road",
				R.drawable.river, null, 2));
		myShops.add(new shops("River Road(2)", "River Road",
				R.drawable.river1, null, 3));
		myShops.add(new shops("Tom mboya(1)", "opp EastMart",
				R.drawable.newshop, null, 4));
		myShops.add(new shops("Tom Mboya Mega", "Tom Mboya st",
				R.drawable.mega, null, 5));
		myShops.add(new shops("Afya Center ", "Tom Mboya st",
				R.drawable.river1, null, 6));
		myShops.add(new shops("Bazaar", "Moi Ave", R.drawable.bazaar, null, 7));
		myShops.add(new shops("Ebrahims opp", "Moi Ave", R.drawable.river,
				null, 8));
		myShops.add(new shops("KenShoes", "Moi Ave", R.drawable.kenshoes, null,
				9));
		myShops.add(new shops("Alibhai", "Kimathi st", R.drawable.alibhai,
				null, 10));
		myShops.add(new shops("Re-Plaza", "City Hall st", R.drawable.newshop,
				null, 11));
		myShops.add(new shops("Jubilee", "Mama Ngina st", R.drawable.kenshoes,
				null, 12));
		myShops.add(new shops("680", "Kenyatta Ave", R.drawable.eighty, null,
				13));
		myShops.add(new shops("MBK", "Muindi Mbingu st", R.drawable.mbk, null,
				14));
		myShops.add(new shops("Tropical Arts", "Muindi Mbingu",
				R.drawable.river, null, 15));
		myShops.add(new shops("LifeStyle", "Monrovia st", R.drawable.lifestyle,
				null, 16));
		myShops.add(new shops("Sarit Centre", "Westlands", R.drawable.sarit,
				null, 17));
		myShops.add(new shops("Galleria", "Langata Rd", R.drawable.galleria,
				null, 18));
		myShops.add(new shops("Yaya Centre", "Arwngs Kodhek Rd",
				R.drawable.yaya, null, 19));
		myShops.add(new shops("Taj Mall", null, R.drawable.taj, null, 20));
		myShops.add(new shops("GreenSpan Mall", "DonHolm",
				R.drawable.greenspan, null, 21));
		myShops.add(new shops("Junction Mall", "Ngong Rd", R.drawable.junction,
				null, 22));
		myShops.add(new shops("Village Mkt", "Limuru Rd", R.drawable.village,
				null, 23));
		myShops.add(new shops("T.R.M)", "Roysambu", R.drawable.trm, null, 24));
		myShops.add(new shops("Capital Centre", "Mombasa Rd",
				R.drawable.capital, null, 25));
		myShops.add(new shops("RidgeWays Mall", "Kiambu Rd",
				R.drawable.ridgeways, null, 26));
		myShops.add(new shops("Bata Nakumatt Prestige", "Ngong Rd",
				R.drawable.prestige, null, 27));

	}

	private class MyListAdapter extends ArrayAdapter<shops> {

		public MyListAdapter() {
			super(ShopFinder.this, R.layout.listview_idea, myShops);
			// TODO Auto-generated constructor stub
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent) {

			View itemView = convertView;
			if (itemView == null) {
				itemView = getLayoutInflater().inflate(R.layout.listview_idea,
						parent, false);
			}

			// find shop to work with
			shops currentShop = myShops.get(position);

			// fill view
			ImageView imageView = (ImageView) itemView
					.findViewById(R.id.icon_image);
			imageView.setImageResource(currentShop.getIcon());

			// the name shown...
			TextView makeName = (TextView) itemView.findViewById(R.id.name);
			makeName.setText(currentShop.getName());

			// the address
			TextView makeAddress = (TextView) itemView
					.findViewById(R.id.shop_adress);
			makeAddress.setText(currentShop.getAddress());

			// the street
			TextView makeStreet = (TextView) itemView
					.findViewById(R.id.shop_street);
			makeStreet.setText(currentShop.getStreet());

			return itemView;
		}
	}

}

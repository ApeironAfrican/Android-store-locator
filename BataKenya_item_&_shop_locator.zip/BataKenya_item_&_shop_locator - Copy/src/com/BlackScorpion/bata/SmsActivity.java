package com.BlackScorpion.bata;

import android.app.ActionBar;
import android.app.Activity;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.telephony.gsm.SmsManager;
import android.view.View;
import android.view.View.OnClickListener;
import android.webkit.WebSettings.LayoutAlgorithm;
import android.webkit.WebSettings.ZoomDensity;
import android.webkit.WebView;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

@SuppressWarnings("deprecation")
public class SmsActivity extends Activity implements OnClickListener,
		OnItemSelectedListener {

	String[] Town = { "Select Town", "Nairobi", "Kisumu", "Mombasa", "Eldoret",
			"Kakamega", "Garissa" };

	Button send, help;
	Spinner spinner;
	EditText edittext;
	TextView item, newSms, pname, pcode, pn, pc, text;

	Typeface font;
	WebView myweb;
	int townCode;
	String size;
	String gotCode, gotName, ImageUrl;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.sms);

		SharedPreferences thePrefs = getSharedPreferences("ImagePrefs",
				Context.MODE_PRIVATE);
		ImageUrl = thePrefs.getString("imageUrl", null);

		font = Typeface.createFromAsset(this.getAssets(), "G-Unit.TTF");

		// <---
		theVariables();
		spinnerActicity();
		// --->

		ActionBar myBar = getActionBar();
		myBar.hide();

		// bundle received from the webClass
		Bundle getBasket = getIntent().getExtras();
		gotCode = getBasket.getString("Code");
		gotName = getBasket.getString("Name");

		pname.setText(gotName);
		pcode.setText(gotCode);

		item.setTypeface(font);
		pn.setTypeface(font);
		pc.setTypeface(font);
		text.setTypeface(font);

		myweb.getSettings().setLoadWithOverviewMode(true);
		myweb.getSettings().setUseWideViewPort(true);
		myweb.setInitialScale(30);
		myweb.setBackgroundColor(Color.TRANSPARENT);
		myweb.getSettings().setDefaultZoom(ZoomDensity.FAR);
		myweb.getSettings().setLayoutAlgorithm(LayoutAlgorithm.SINGLE_COLUMN);

		// myWeb.setWebViewClient(new Client());

		/*
		 * String data = "<html><body><img id=\"resizeImage\"src=\"" + ImageUrl
		 * + "\"width=\"100%\" alt=\"\" align=\"middle\"/></body></html>";
		 * myweb.loadData(data, "text/html;charset=UTF-8", null);
		 */
		myweb.loadUrl(ImageUrl);

	}

	private void spinnerActicity() {
		// TODO Auto-generated method stub

		ArrayAdapter<String> myAdapter = new ArrayAdapter<String>(this,
				android.R.layout.simple_spinner_dropdown_item, Town);
		spinner.setAdapter(myAdapter);
		spinner.setOnItemSelectedListener(this);
	}

	private void theVariables() {
		// TODO Auto-generated method stub

		myweb = (WebView) findViewById(R.id.webView1);
		send = (Button) findViewById(R.id.sendsms);
		help = (Button) findViewById(R.id.help);
		spinner = (Spinner) findViewById(R.id.spinner1);
		edittext = (EditText) findViewById(R.id.shoecode);
		pname = (TextView) findViewById(R.id.pName);
		pcode = (TextView) findViewById(R.id.tpcode);
		pc = (TextView) findViewById(R.id.textView1);
		pn = (TextView) findViewById(R.id.textView2);
		text = (TextView) findViewById(R.id.textView3);
		item = (TextView) findViewById(R.id.textView4);

		send.setOnClickListener(this);
		help.setOnClickListener(this);

	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		switch (v.getId()) {

		case R.id.sendsms:
			smsTime();
			break;

		case R.id.help:

			Toast.makeText(
					this,
					"Enter the required size in the edit box and click send. You will receive a comfirmation text shortly",
					Toast.LENGTH_LONG).show();

			break;

		}
	}

	private void smsTime() {

		String Sent = "SMS_SENT";
		String Delivered = "SMS_DELIVERED";

		PendingIntent sentPend = PendingIntent.getBroadcast(this, 0,
				new Intent(Sent), 0);

		PendingIntent deliveredPend = PendingIntent.getBroadcast(this, 0,
				new Intent(Delivered), 0);

		registerReceiver(new BroadcastReceiver() {

			@Override
			public void onReceive(Context arg0, Intent arg1) {
				// TODO Auto-generated method stub
				switch (getResultCode()) {

				case Activity.RESULT_OK:
					Toast.makeText(getBaseContext(), "Request sent",
							Toast.LENGTH_SHORT).show();
					break;
				case SmsManager.RESULT_ERROR_GENERIC_FAILURE:
					Toast.makeText(getBaseContext(), "Error...Check Network",
							Toast.LENGTH_SHORT).show();
					break;
				case SmsManager.RESULT_ERROR_NO_SERVICE:
					Toast.makeText(getBaseContext(),
							"No Service ... Please try later",
							Toast.LENGTH_SHORT).show();
					break;

				}
			}
		}, new IntentFilter(Sent));

		registerReceiver(new BroadcastReceiver() {

			@Override
			public void onReceive(Context arg0, Intent arg1) {
				// TODO Auto-generated method stub
				switch (getResultCode()) {

				case Activity.RESULT_OK:
					Toast.makeText(getBaseContext(), "Request sent",
							Toast.LENGTH_SHORT).show();
					break;
				case Activity.RESULT_CANCELED:
					Toast.makeText(getBaseContext(),
							"Request not sent...Check Network",
							Toast.LENGTH_SHORT).show();
					break;

				}
			}
		}, new IntentFilter(Delivered));

		size = edittext.getText().toString();
		String Message = townCode + " " + gotCode + " " + size;
		String Number = "+254727372000";

		// TODO Auto-generated method stub
		SmsManager mySms = SmsManager.getDefault();
		mySms.sendTextMessage(Number, null, Message, sentPend, deliveredPend);

	}

	@Override
	public void onItemSelected(AdapterView<?> arg0, View arg1, int arg2,
			long arg3) {

		int position = spinner.getSelectedItemPosition();
		switch (position) {

		case 1:
			townCode = 51101;
			Toast.makeText(getApplicationContext(), "Hi,Nairobian",
					Toast.LENGTH_LONG).show();

			break;

		default:
			Toast.makeText(getApplicationContext(), "Please Select your town",
					Toast.LENGTH_LONG).show();
			break;
		}
	}

	@Override
	public void onNothingSelected(AdapterView<?> arg0) {
		// TODO Auto-generated method stub
		Toast.makeText(getApplicationContext(), "Please Select your town",
				Toast.LENGTH_LONG).show();
	}

}

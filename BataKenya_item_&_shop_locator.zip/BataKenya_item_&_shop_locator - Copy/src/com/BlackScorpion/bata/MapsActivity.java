package com.BlackScorpion.bata;

import android.app.ActionBar;
import android.app.Activity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;

import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

public class MapsActivity extends Activity {

	String hilton1, river11, river21, tomboya1, mega1, afya1, bazaar1,
			ebrahims1, kenshoes1, alibhai1, replaza1, jubilee1, kenyatta6801,
			mbk1, tropical1, lifestyle1, sarit1, galleria1, yaya1, taj1,
			greenspan1, junction1, village1, trm1, capital1, ridgeways1;

	LatLng x;
	int myCode;

	private GoogleMap myMap;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.maps_activity);

		Bundle gotBasket = getIntent().getExtras();
		myCode = gotBasket.getInt("mapCode");

		ActionBar myBar = getActionBar();
		myBar.hide();

		myMap = ((MapFragment) getFragmentManager().findFragmentById(R.id.map))
				.getMap();

		getToPlace();

	}

	private void getToPlace() {
		// TODO Auto-generated method stub

		if (myCode == 1) {
			x = new LatLng(-1.285322, 36.824638999999934);
			myMap.addMarker(new MarkerOptions().position(x).title(
					"The Hilton Shop"));
		} else if (myCode == 2) {
			x = new LatLng(-1.2812681302355315, 36.82538866996765);
			myMap.addMarker(new MarkerOptions().position(x).title("River Road"));
		} else if (myCode == 3) {
			x = new LatLng(-1.281900973217523, 36.82621479034424);
			myMap.addMarker(new MarkerOptions().position(x).title(
					"River Road(2)"));
		} else if (myCode == 4) {
			x = new LatLng(-1.2825917368502477, 36.823680102825165);
			myMap.addMarker(new MarkerOptions().position(x).title(
					"Tom Mboya(1)"));
		} else

		if (myCode == 5) {
			x = new LatLng(-1.2834980961971727, 36.82485222816467);
			myMap.addMarker(new MarkerOptions().position(x).title(
					"Tom Mboya Mega"));
		} else if (myCode == 6) {
			x = new LatLng(-1.2875600839136727, 36.82769000530243);
			myMap.addMarker(new MarkerOptions().position(x)
					.title("Afya Centre"));
		} else if (myCode == 7) {
			x = new LatLng(-1.2819696201896356, 36.82166576385498);

			myMap.addMarker(new MarkerOptions().position(x)
					.title("Bazaar Shop"));
		} else if (myCode == 8) {
			x = new LatLng(-1.2829725150765363, 36.82324826717377);

			myMap.addMarker(new MarkerOptions().position(x).title(
					"Moi Avenue(1)"));
		} else if (myCode == 9) {
			x = new LatLng(-1.2843961423658259, 36.82470001280308);

			myMap.addMarker(new MarkerOptions().position(x).title(
					"RKenShoes shop)"));
		} else if (myCode == 10) {
			x = new LatLng(-1.283683122178227, 36.822693049907684);

			myMap.addMarker(new MarkerOptions().position(x).title(
					"Alibhai Sharrif shop"));
		} else if (myCode == 11) {
			x = new LatLng(-1.2872704784641, 36.82440161705017);
			myMap.addMarker(new MarkerOptions().position(x).title(
					"Re-Plaza shop)"));
		} else if (myCode == 12) {
			x = new LatLng(-1.2855650234829807, 36.823060512542725);
			myMap.addMarker(new MarkerOptions().position(x).title("Jubilee"));
		} else if (myCode == 13) {
			x = new LatLng(-1.285243239396499, 36.820324659347534);

			myMap.addMarker(new MarkerOptions().position(x).title(
					"SixEighty Hotel Shop"));
		} else if (myCode == 14) {
			x = new LatLng(-1.2817658233196607, 36.818937957286835);
			myMap.addMarker(new MarkerOptions().position(x).title(
					"Muindi Mbingu Shop"));
		} else if (myCode == 15) {
			x = new LatLng(-1.2837061833210466, 36.820051074028015);

			myMap.addMarker(new MarkerOptions().position(x).title(
					"Tropical Arts Shop"));
		} else if (myCode == 16) {
			x = new LatLng(-1.2814359941404774, 36.81825399398804);
			myMap.addMarker(new MarkerOptions().position(x).title(
					"LifeStyle Shop"));
		} else if (myCode == 17) {
			x = new LatLng(-1.2612401789454135, 36.802568435668945);
			myMap.addMarker(new MarkerOptions().position(x).title(
					"Sarit Centre shop"));
		} else if (myCode == 18) {
			x = new LatLng(-1.343052, 36.76621899999998);

			myMap.addMarker(new MarkerOptions().position(x).title(
					"Galleria Mall Shop"));
		} else if (myCode == 19) {
			x = new LatLng(-1.292959, 36.78784100000007);

			myMap.addMarker(new MarkerOptions().position(x).title(
					"Yaya Centre Shop"));
		} else if (myCode == 20) {
			x = new LatLng(-1.3229035, 36.8988114);
			myMap.addMarker(new MarkerOptions().position(x).title(
					"Taj Mall Shop"));
		} else if (myCode == 21) {
			x = new LatLng(-1.288725, 36.90085499999998);

			myMap.addMarker(new MarkerOptions().position(x).title(
					"GreenSpan Mall Shop"));
		} else if (myCode == 22) {
			x = new LatLng(-1.298243, 36.76242000000002);
			myMap.addMarker(new MarkerOptions().position(x).title(
					"The Junction Mall Shop"));
		} else if (myCode == 23) {
			x = new LatLng(-1.229404, 36.80480299999999);

			myMap.addMarker(new MarkerOptions().position(x).title(
					"Village Market shop"));
		} else if (myCode == 24) {
			x = new LatLng(-1.21967, 36.88874199999998);

			myMap.addMarker(new MarkerOptions().position(x).title(
					"Thika Road Mall Shop"));
		} else if (myCode == 25) {
			x = new LatLng(-1.316715, 36.833977000000004);

			myMap.addMarker(new MarkerOptions().position(x).title(
					"Capital Centre Shop"));
		} else if (myCode == 26) {
			x = new LatLng(-1.2253713983593508, 36.84016227722168);
			myMap.addMarker(new MarkerOptions().position(x).title(
					"RidgeWays Mall Shop"));
		}
		else if (myCode == 27) {
			x = new LatLng(-1.300067, 36.78735800000004);
			myMap.addMarker(new MarkerOptions().position(x).title(
					"Nakumatt Prestige Shop"));
		}

		myMap.setMapType(GoogleMap.MAP_TYPE_NORMAL);
		CameraUpdate myUpdate = CameraUpdateFactory.newLatLngZoom(x, 16);
		myMap.animateCamera(myUpdate);
	}
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// TODO Auto-generated method stub
		super.onCreateOptionsMenu(menu);
		MenuInflater blow = getMenuInflater();
		blow.inflate(R.menu.maps, menu);
		return true;
	}

	
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// TODO Auto-generated method stub
		switch (item.getItemId()) {

		case R.id.map1:
			myMap.setMapType(GoogleMap.MAP_TYPE_NORMAL);
			break;
		case R.id.map2:
			myMap.setMapType(GoogleMap.MAP_TYPE_TERRAIN);
			break;
		case R.id.map3:
			myMap.setMapType(GoogleMap.MAP_TYPE_SATELLITE);
			break;
		case R.id.map4:
			myMap.setMapType(GoogleMap.MAP_TYPE_HYBRID);
			break;

		default:
			break;

		}
		return false;
	}
}

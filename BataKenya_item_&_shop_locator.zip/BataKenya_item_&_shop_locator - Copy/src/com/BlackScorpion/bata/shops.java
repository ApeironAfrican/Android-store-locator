package com.BlackScorpion.bata;

public class shops {
	private String name;
	private String street;
	private String address;
	private int icon;
	private int code;

	public shops(String name, String street, int icon, String address, int code) {
		// TODO Auto-generated constructor stub
		super();
		this.name = name;
		this.street = street;
		this.address = address;
		this.icon = icon;
		this.code = code;

	}

	public String getAddress() {
		return address;
	}

	public int getIcon() {
		return icon;
	}

	public String getStreet() {
		return street;
	}

	public String getName() {
		return name;
	}

	public int getCode() {
		return code;
	}

}

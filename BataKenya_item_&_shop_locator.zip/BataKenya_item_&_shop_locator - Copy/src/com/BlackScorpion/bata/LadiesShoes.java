package com.BlackScorpion.bata;

import android.annotation.SuppressLint;
import android.app.ActionBar;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

@SuppressLint({ "SetJavaScriptEnabled", "JavascriptInterface" })
public class LadiesShoes extends Activity {

	String theUrl = "http://batakenya.com/webbata/faces/tiles/category.jsp?catalogueID=70&q=&sid=&bid=&prc=&k1=&k2=&k3=&k4=&k5=&k6=&k7=&k8=&k9=&k10=&k11=&k12=&categoryID=5176&parentCategoryID=5170&catSeqDisplay=Y";
	ProgressBar progress;
	TextView contentView, leString, imagetxt;

	Typeface font;
	WebView wv;
	String code = null;
	String myString = null;
	String name = null;
	ImageView lights;
	String myimage, mycode, myname;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);

		setContentView(R.layout.main_web_activity);

		font = Typeface.createFromAsset(this.getAssets(), "G-Unit.TTF");

		attributes();

		webSettings();

		ActionBarstuff();

	}

	@SuppressLint({ "InflateParams", "NewApi" })
	private void ActionBarstuff() {

		ActionBar mActionBar = getActionBar();
		mActionBar.setDisplayShowHomeEnabled(false);
		mActionBar.setDisplayShowTitleEnabled(false);
		mActionBar.setSplitBackgroundDrawable(new ColorDrawable(Color.BLACK));

		LayoutInflater minInflater = LayoutInflater.from(this);

		View mCustomView = minInflater.inflate(R.layout.actionbar_layout, null);

		TextView mTitleText = (TextView) mCustomView.findViewById(R.id.text);
		mTitleText.setTypeface(font);
		mTitleText.setText("Ladies Section");

		Button mButton = (Button) mCustomView.findViewById(R.id.button);
		mButton.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				if (android.os.Build.VERSION.SDK_INT < 19) {
					// <--- This part executes only if version is below 19

					if (code == null) {
						Toast.makeText(LadiesShoes.this,
								"Please select a specific item",
								Toast.LENGTH_LONG).show();
					} else {

						Bundle bag = new Bundle();
						bag.putString("Code", code);
						bag.putString("Name", name);
						Intent end = new Intent(LadiesShoes.this,
								SmsActivity.class);
						end.putExtras(bag);
						startActivity(end);
						overridePendingTransition(R.anim.slide_in_left,
								R.anim.slide_out_left);
					}
					// --->

				} else {
					// <-----Executes if version is above 18
					if (mycode == null) {
						Toast.makeText(LadiesShoes.this,
								"Please select a specific item",
								Toast.LENGTH_LONG).show();
					} else {
						Bundle basket = new Bundle();
						basket.putString("Code", mycode);
						basket.putString("Name", myname);

						Intent send = new Intent(LadiesShoes.this,
								SmsActivity.class);
						send.putExtras(basket);
						startActivity(send);
						overridePendingTransition(R.anim.slide_in_left,
								R.anim.slide_out_left);
					}
					// ----->

				}

			}

		});

		mActionBar.setCustomView(mCustomView);
		mActionBar.setDisplayShowCustomEnabled(true);
	}

	private void attributes() {
		// TODO Auto-generated method stub

		contentView = (TextView) findViewById(R.id.contentText);
		leString = (TextView) findViewById(R.id.lestring);
		imagetxt = (TextView) findViewById(R.id.imagetext);
		lights = (ImageView) findViewById(R.id.imageView1);
		progress = (ProgressBar) findViewById(R.id.progressBar1);

		wv = (WebView) findViewById(R.id.webView1);

	}

	@JavascriptInterface
	private void webSettings() {
		// TODO Auto-generated method stub

		wv.getSettings().setLoadWithOverviewMode(true);
		wv.getSettings().setUseWideViewPort(true);
		wv.getSettings().setDisplayZoomControls(true);
		wv.getSettings().setBuiltInZoomControls(true);
		wv.getSettings().setSupportZoom(true);
		wv.setBackgroundColor(Color.TRANSPARENT);
		wv.setWebViewClient(new Client());
		wv.getSettings().setJavaScriptEnabled(true);

		// <--- This interface only executes if the version is below 19
		@SuppressWarnings("unused")
		class MyJavascriptInterface {

			private TextView contentView;

			public MyJavascriptInterface(TextView aContentView) {
				contentView = aContentView;
			}

			public void processContent(String aContent) {
				final String content = aContent;
				contentView.post(new Runnable() {

					@Override
					public void run() {
						// TODO Auto-generated method stub
						contentView.setText(content);

						code = content;

						lights.setImageResource(R.drawable.glossygreen);
						Toast.makeText(LadiesShoes.this,
								"You can send request now!", Toast.LENGTH_LONG)
								.show();
					}
				});
			}
		}
		wv.addJavascriptInterface(new MyJavascriptInterface(contentView),
				"INTERFACE");

		@SuppressWarnings("unused")
		class TheJavascriptInterface {

			private TextView leString;

			public TheJavascriptInterface(TextView aString) {
				leString = aString;

			}

			public void processContent(String bString) {
				final String theString = bString;

				leString.post(new Runnable() {

					@Override
					public void run() {
						// TODO Auto-generated method stub
						leString.setText(theString);

						name = theString;
					}
				});

			}
		}
		wv.addJavascriptInterface(new TheJavascriptInterface(leString), "INTER");

		@SuppressWarnings("unused")
		class JInterface {

			public JInterface(TextView myText) {
				imagetxt = myText;

			}

			public void processContent(String string) {
				final String imgString = string;

				imagetxt.post(new Runnable() {

					@JavascriptInterface
					@Override
					public void run() {
						// TODO Auto-generated method stub

						SharedPreferences ImgPrefs = getSharedPreferences(
								"ImagePrefs", Context.MODE_PRIVATE);

						SharedPreferences.Editor editor = ImgPrefs.edit();
						editor.putString("imageUrl", imgString);
						editor.commit();
					}
				});

			}
		}
		wv.addJavascriptInterface(new JInterface(imagetxt), "JInterface");
		// --->
		wv.loadUrl(theUrl);

	}

	@SuppressLint("NewApi")
	class Client extends WebViewClient {

		public void onPageFinished(WebView view, String url) {
			// TODO Auto-generated method stub
			if (android.os.Build.VERSION.SDK_INT < 19) {
				view.loadUrl("javascript:window.INTERFACE.processContent(document.getElementsByName('productSKUCode')[0].value);");
				view.loadUrl("javascript:window.INTER.processContent(document.getElementsByName('productName')[0].value);");
				view.loadUrl("javascript:window.JInterface.processContent(document.getElementById('mainImg').src);");

			} else {
				view.evaluateJavascript(
						"javascript:document.getElementsByName('productSKUCode')[0].value;",
						new ValueCallback<String>() {
							@Override
							public void onReceiveValue(String codevalue) {
								if (codevalue.contains("\"")) {
									mycode = codevalue.replace("\"", "");

									if (mycode != null) {
										lights.setImageResource(R.drawable.glossygreen);
										Toast.makeText(LadiesShoes.this,
												"You can send request now!",
												Toast.LENGTH_LONG).show();
									}
								}
							}
						});
				view.evaluateJavascript(
						"javascript:document.getElementsByName('productName')[0].value;",
						new ValueCallback<String>() {
							@Override
							public void onReceiveValue(String namevalue) {
								if (namevalue.contains("\"")) {
									myname = namevalue.replace("\"", "");
								}
							}
						});
				view.evaluateJavascript(
						"javascript:document.getElementById('mainImg').src;",
						new ValueCallback<String>() {
							@Override
							public void onReceiveValue(String imgvalue) {
								if (imgvalue.contains("\"")) {
									myimage = imgvalue.replace("\"", "");
								}

								SharedPreferences ImgPrefs = getSharedPreferences(
										"ImagePrefs", Context.MODE_PRIVATE);

								SharedPreferences.Editor editor = ImgPrefs
										.edit();
								editor.putString("imageUrl", myimage);
								editor.commit();

							}
						});
			}

			progress.setVisibility(View.GONE);
			super.onPageFinished(view, url);
		}

		@Override
		public void onPageStarted(WebView view, String url, Bitmap favicon) {
			// TODO Auto-generated method stub
			progress.setVisibility(View.VISIBLE);
			super.onPageStarted(view, url, favicon);
		}

		@JavascriptInterface
		public void onReceivedError(WebView view, int errorCode,
				String description, String failingUrl) {

			Toast.makeText(
					LadiesShoes.this,
					"Sorry cant load the page.\n Something's wrong with your network",
					Toast.LENGTH_LONG).show();
		};

		@JavascriptInterface
		@Override
		public boolean shouldOverrideUrlLoading(WebView view, String url) {
			// TODO Auto-generated method stub

			view.loadUrl(url);
			return true;
		}
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		super.onCreateOptionsMenu(menu);
		MenuInflater blow = getMenuInflater();
		blow.inflate(R.menu.ladiesmenu, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// TODO Auto-generated method stub
		switch (item.getItemId()) {
		case R.id.boots:
			theUrl = "http://batakenya.com/webbata/faces/tiles/category.jsp?catalogueID=70&q=&sid=&bid=&prc=&k1=&k2=&k3=&k4=&k5=&k6=&k7=&k8=&k9=&k10=&k11=&k12=&categoryID=5325&parentCategoryID=5170&catSeqDisplay=Y";
			wv.loadUrl(theUrl);
			break;
		case R.id.dress:
			theUrl = "http://batakenya.com/webbata/faces/tiles/category.jsp?catalogueID=70&q=&sid=&bid=&prc=&k1=&k2=&k3=&k4=&k5=&k6=&k7=&k8=&k9=&k10=&k11=&k12=&categoryID=5176&parentCategoryID=5170&catSeqDisplay=Y";
			wv.loadUrl(theUrl);
			break;
		case R.id.casuals:
			theUrl = "http://batakenya.com/webbata/faces/tiles/category.jsp?catalogueID=70&q=&sid=&bid=&prc=&k1=&k2=&k3=&k4=&k5=&k6=&k7=&k8=&k9=&k10=&k11=&k12=&categoryID=5177&parentCategoryID=5170&catSeqDisplay=Y";
			wv.loadUrl(theUrl);
			break;
		case R.id.sandles:
			theUrl = "http://batakenya.com/webbata/faces/tiles/category.jsp?catalogueID=70&q=&sid=&bid=&prc=&k1=&k2=&k3=&k4=&k5=&k6=&k7=&k8=&k9=&k10=&k11=&k12=&categoryID=5178&parentCategoryID=5170&catSeqDisplay=Y";
			wv.loadUrl(theUrl);
			break;
		case R.id.sports:
			theUrl = "http://batakenya.com/webbata/faces/tiles/category.jsp?catalogueID=70&q=&sid=&bid=&prc=&k1=&k2=&k3=&k4=&k5=&k6=&k7=&k8=&k9=&k10=&k11=&k12=&categoryID=5179&parentCategoryID=5170&catSeqDisplay=Y";
			wv.loadUrl(theUrl);
			break;
		case R.id.handbags:
			theUrl = "http://batakenya.com/webbata/faces/tiles/category.jsp?catalogueID=70&q=&sid=&bid=&prc=&k1=&k2=&k3=&k4=&k5=&k6=&k7=&k8=&k9=&k10=&k11=&k12=&categoryID=5217&parentCategoryID=5170&catSeqDisplay=Y";
			wv.loadUrl(theUrl);
			break;
		case R.id.accessories:
			Toast.makeText(this, "not yet", Toast.LENGTH_LONG).show();
		case R.id.backAction:
			if (wv.canGoBack())
				wv.goBack();
			break;
		case R.id.fowardAction:
			if (wv.canGoForward())
				wv.goForward();
			break;
		case R.id.reloadAction:
			wv.reload();
			break;
		case R.id.homeAction:
		case R.id.home:
			Intent hm = new Intent("com.BlackScorpion.bata.MAINACTIVITY");
			startActivity(hm);
			overridePendingTransition(R.anim.slide_in_left,
					R.anim.slide_out_left);
			break;
		case R.id.helpAction:
			Intent i = new Intent("com.BlackScorpion.bata.HELP");
			startActivity(i);
			break;
		}
		return false;
	}

}
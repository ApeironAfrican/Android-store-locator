package com.BlackScorpion.bata;

import android.app.ActionBar;
import android.app.Activity;
import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;

public class SettingClass extends Activity implements OnClickListener {

	Button skip;
	TextView steps, info;
	Typeface font;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.settingslayout);

		ActionBar myBar = getActionBar();
		myBar.hide();

		font = Typeface.createFromAsset(this.getAssets(), "G-Unit.TTF");

		skip = (Button) findViewById(R.id.buttonskip);
		steps = (TextView) findViewById(R.id.View1);
		steps.setTypeface(font);

		skip.setOnClickListener(this);
	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		switch (v.getId()) {

		case R.id.buttonskip:
			Intent intent = new Intent(this, MainActivity.class);
			startActivity(intent);
			overridePendingTransition(R.anim.slide_in_left,
					R.anim.slide_out_left);
			break;

		default:
			break;
		}
	}

	@Override
	protected void onPause() {
		// TODO Auto-generated method stub
		super.onPause();
		finish();
	}
}

package com.BlackScorpion.bata;

public class ShoeClass {

	private String title;
	private int icon;
	private int code;

	public ShoeClass(String title, int icon,int code) {
		// TODO Auto-generated constructor stub
		super();

		this.icon = icon;
		this.title = title;
		this.code = code;
	}

	public String gettitle() {
		return title;
	}

	public int getIcon() {
		return icon;
	}
	public int getCode() {
		return code;
	}
}

package com.BlackScorpion.bata;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.os.Bundle;
import android.widget.TextView;

public class Notifier extends Activity {

	TextView text;
	Typeface font;
	Context context = this;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.notifier);

		// Receives data from parse

		Bundle bundle = getIntent().getExtras();
		final String fromParse = bundle.getString("newUrl");
		final String textToDisplay = bundle.getString("textToShow");

		text.setTypeface(font);
		text.setText(textToDisplay);

		// Saves data from parse into preferences
		SharedPreferences prefs = getSharedPreferences("UrlPrefs",
				Context.MODE_PRIVATE);
		SharedPreferences.Editor editor = prefs.edit();
		editor.putString("newArrivalsUrl", fromParse);
		editor.commit();

		Thread thread = new Thread() {
			@Override
			public void run() {
				try {
					sleep(1500);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} finally {

					// Puts the url into the bundle
					Bundle basket = new Bundle();
					basket.putString("myString", fromParse);

					// Opens the New Arrivals class and passes the bundle
					Intent intent = new Intent(context, NewArrivals.class);
					intent.putExtras(basket);
					startActivity(intent);
					overridePendingTransition(R.anim.slide_in_left,
							R.anim.slide_out_left);
				}
			}
		};
		thread.start();
	}

	@Override
	protected void onPause() {
		// TODO Auto-generated method stub
		super.onPause();
		finish();
	}
}

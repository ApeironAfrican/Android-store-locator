package com.BlackScorpion.bata;

import android.app.ActionBar;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends Activity implements OnClickListener {

	Button help, men, ladies, kids, extra, finder, recents, contacts;

	Typeface font;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);

		setContentView(R.layout.activity_main);

		ActionBar myBar = getActionBar();
		myBar.hide();
		myVariables();

		recents.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub

				SharedPreferences MessagePrefs = getSharedPreferences(
						"SmsPrefs", Context.MODE_PRIVATE);
				String smsMessage = MessagePrefs.getString("Message", null);
				if (smsMessage != null) {
					Intent recentIntent = new Intent(MainActivity.this,
							ShowMessage.class);
					startActivity(recentIntent);
					overridePendingTransition(R.anim.slide_in_left,
							R.anim.slide_out_left);
				} else {
					Toast.makeText(MainActivity.this,
							"There are no recent messages", Toast.LENGTH_LONG)
							.show();
				}
			}
		});
	}

	private void myVariables() {
		// TODO Auto-generated method stub

		help = (Button) findViewById(R.id.help);
		men = (Button) findViewById(R.id.men);
		ladies = (Button) findViewById(R.id.ladies);
		kids = (Button) findViewById(R.id.kids);
		extra = (Button) findViewById(R.id.extras);
		finder = (Button) findViewById(R.id.find);
		recents = (Button) findViewById(R.id.recented);
		contacts = (Button) findViewById(R.id.contact);

		help.setOnClickListener(this);
		men.setOnClickListener(this);
		ladies.setOnClickListener(this);
		kids.setOnClickListener(this);
		extra.setOnClickListener(this);
		finder.setOnClickListener(this);

		contacts.setOnClickListener(this);

	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		switch (v.getId()) {
		case R.id.help:
			Intent helpIntent = new Intent(this, SettingClass.class);
			startActivity(helpIntent);
			overridePendingTransition(R.anim.slide_in_left,
					R.anim.slide_out_left);
			break;
		case R.id.men:
			Intent menIntent = new Intent("com.BlackScorpion.bata.THEWEBCLASS");
			startActivity(menIntent);
			overridePendingTransition(R.anim.slide_in_left,
					R.anim.slide_out_left);
			break;
		case R.id.ladies:
			Intent ladyIntent = new Intent("com.BlackScorpion.bata.LADIESSHOES");
			startActivity(ladyIntent);
			overridePendingTransition(R.anim.slide_in_left,
					R.anim.slide_out_left);
			break;
		case R.id.kids:
			Intent childIntent = new Intent("com.BlackScorpion.bata.CHILDREN");
			startActivity(childIntent);
			overridePendingTransition(R.anim.slide_in_left,
					R.anim.slide_out_left);
			break;
		case R.id.extras:
			SharedPreferences thePrefs = getSharedPreferences("UrlPrefs",
					Context.MODE_PRIVATE);
			String theSubUrlToLoad = thePrefs.getString("newArrivalsUrl", null);

			if (theSubUrlToLoad == null) {

				Toast.makeText(
						MainActivity.this,
						"There are no new arrivals or promotions in stores yet...",
						Toast.LENGTH_LONG).show();
			} else {
				Intent newArrivals = new Intent(
						"com.BlackScorpion.bata.NEWARRIVALS");
				newArrivals.putExtra("fromNewArrivals", theSubUrlToLoad);
				startActivity(newArrivals);
				overridePendingTransition(R.anim.slide_in_left,
						R.anim.slide_out_left);
			}
			break;
		case R.id.find:
			Intent shopsIntent = new Intent("com.BlackScorpion.bata.SHOPFINDER");
			startActivity(shopsIntent);
			overridePendingTransition(R.anim.slide_in_left,
					R.anim.slide_out_left);
			break;

		case R.id.contact:

			Toast.makeText(MainActivity.this, "Add stuff here",
					Toast.LENGTH_LONG).show();

			break;

		default:
			break;
		}
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// TODO Auto-generated method stub
		super.onCreateOptionsMenu(menu);
		MenuInflater blow = getMenuInflater();
		blow.inflate(R.menu.main, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// TODO Auto-generated method stub
		switch (item.getItemId()) {

		case R.id.recent:

			Intent recentIntent = new Intent(this, ShowMessage.class);
			startActivity(recentIntent);

			overridePendingTransition(R.anim.slide_in_left,
					R.anim.slide_out_left);

			break;

		case R.id.setting:
			Intent i = new Intent(this, MyPrefs.class);
			startActivity(i);
			break;

		case R.id.exit:
			finish();
			break;

		default:
			break;

		}
		return false;
	}

}

/** Automatically generated file. DO NOT MODIFY */
package com.BlackScorpion.bata;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}